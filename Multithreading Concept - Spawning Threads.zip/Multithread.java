import java.util.ArrayList;

// Implement the MultithreadingDemo by extending the Thread class

class MultithreadingDemo extends Thread
{ 
	static ArrayList <String> tact=new ArrayList<String>();
	static long tid;
	Thread t;

// Implement the run method here
public void run()
{
String s=Thread.currentThread().getName()+" is running";
System.out.println(s);
tact.add(s);
}

}
//Main Class 

public class Multithread 
{ 
 public static void main(String[] args) 
 { 
     int n = 8; // Number of threads 
     for (int i=0; i<n; i++) 
     { 
         try
         {
             // create the thread with name and start the thread here
             String name="Thread"+i;
             Thread t=new Thread(new MultithreadingDemo(),name);
             t.start();
             t.join();
         }
         catch(Exception e)
         {
             e.printStackTrace();
         }
     } 
 }
}
